var namespaces_dup =
[
    [ "anonymous_namespace{apr_aprepro.cc}", "namespaceanonymous__namespace_02apr__aprepro_8cc_03.html", null ],
    [ "anonymous_namespace{apr_builtin.cc}", "namespaceanonymous__namespace_02apr__builtin_8cc_03.html", null ],
    [ "anonymous_namespace{apr_parser.cc}", "namespaceanonymous__namespace_02apr__parser_8cc_03.html", null ],
    [ "anonymous_namespace{apr_util.cc}", "namespaceanonymous__namespace_02apr__util_8cc_03.html", null ],
    [ "SEAMS", "namespaceSEAMS.html", "namespaceSEAMS" ],
    [ "trmclr", "namespacetrmclr.html", null ]
];