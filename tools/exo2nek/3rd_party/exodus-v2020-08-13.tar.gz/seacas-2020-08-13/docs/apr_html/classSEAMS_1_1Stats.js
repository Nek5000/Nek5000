var classSEAMS_1_1Stats =
[
    [ "Stats", "classSEAMS_1_1Stats.html#ac3e4cf0177fd919d35eb8e38eab23e1d", null ],
    [ "deviation", "classSEAMS_1_1Stats.html#ac86a9beabf50195b4a0193f0c848078f", null ],
    [ "mean", "classSEAMS_1_1Stats.html#a1259e4c80165367ba2c1691f80b67e31", null ],
    [ "newsample", "classSEAMS_1_1Stats.html#a16096f819d2fd42695898c4a2fbedcc4", null ],
    [ "variance", "classSEAMS_1_1Stats.html#a0b27a614bbcb23ed0bc3f2763d124eff", null ],
    [ "Mean", "classSEAMS_1_1Stats.html#a887267ca516552650a293b633c12440c", null ],
    [ "Numnums", "classSEAMS_1_1Stats.html#ad3b3cd0f41f3304dc4b6faeea3f624d8", null ],
    [ "StdDev", "classSEAMS_1_1Stats.html#a0f9edd96967e4924fde25ab9a8b47a5a", null ]
];