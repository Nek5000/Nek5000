var searchData=
[
  ['_5fvalue_0',['_value',['../structtrmclr_1_1Style.html#a6c474615464465ce751122b4c79d7a48',1,'trmclr::Style']]]
];
