var namespacetrmclr =
[
    [ "Attribute", "structtrmclr_1_1Attribute.html", "structtrmclr_1_1Attribute" ],
    [ "Background", "structtrmclr_1_1Background.html", "structtrmclr_1_1Background" ],
    [ "Foreground", "structtrmclr_1_1Foreground.html", "structtrmclr_1_1Foreground" ],
    [ "Style", "structtrmclr_1_1Style.html", "structtrmclr_1_1Style" ]
];