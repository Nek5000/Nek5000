#ifndef PACKAGEWITHSUBPACKAGES_C_HPP_
#define PACKAGEWITHSUBPACKAGES_C_HPP_

#include <string>

namespace WithSubpackages {

std::string getC();

std::string depsC();

}

#endif /* PACKAGEWITHSUBPACKAGES_C_HPP_ */
