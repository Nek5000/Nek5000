#ifndef SIMPLE_TPL_HPP
#define SIMPLE_TPL_HPP

namespace SimpleTpl {

/** \brief . */
double cube(const double &v);

} // namespace SimpleTpl

#endif // SIMPLE_TPL_HPP
