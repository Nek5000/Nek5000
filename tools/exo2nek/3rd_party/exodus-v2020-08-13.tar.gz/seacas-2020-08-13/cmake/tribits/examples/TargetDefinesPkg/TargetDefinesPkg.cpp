#include "TargetDefinesPkg.hpp"

std::string TargetDefinesPkg::passThrough(const std::string &str)
{
  return str;
}
