#include "SharedOnly.hpp"

std::string MixedSharedStaticLibs::sharedPassThrough(const std::string &str)
{
  return str;
}
