#ifndef TARGETDEFINESPKG_HPP_
#define TARGETDEFINESPKG_HPP_

#include <string>

namespace TargetDefinesPkg {

std::string passThrough(const std::string &str);

}

#endif /* TARGETDEFINESPKG_HPP_ */
