#include "c_b_mixed_lang.hpp"

#include <iostream>

int main() 
{
  std::cout << WithSubpackages::c_b_mixed_lang() << "\n";
}
