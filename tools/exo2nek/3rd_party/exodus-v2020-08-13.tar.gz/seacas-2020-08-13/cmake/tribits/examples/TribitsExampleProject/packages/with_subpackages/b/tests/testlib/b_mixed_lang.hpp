#ifndef WITHSUBPACKAGES_B_MIXED_LANG_HPP
#define WITHSUBPACKAGES_B_MIXED_LANG_HPP

#include <string>

namespace WithSubpackages {

std::string b_mixed_lang();

}

#endif // WITHSUBPACKAGES_B_MIXED_LANG_HPP
