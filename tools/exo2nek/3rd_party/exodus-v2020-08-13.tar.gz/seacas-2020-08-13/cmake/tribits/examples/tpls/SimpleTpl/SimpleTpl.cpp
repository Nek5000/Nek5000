#include "SimpleTpl.hpp"

double SimpleTpl::cube(const double &v)
{
  return v*v*v;
}
